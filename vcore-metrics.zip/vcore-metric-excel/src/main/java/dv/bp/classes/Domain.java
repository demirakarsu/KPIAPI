package dv.bp.classes;


import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class Domain {
	private String domainName;
	private Integer numberOfWorkers;
	private Double vCoreSize;
	private Double averageCPU;
	private Double averageMemory;
	private Double peakCPU;
	private Double peakMemory;
	
	public Domain(Integer workers, Double vCoreSize, String domain){
		this.numberOfWorkers = workers;
		this.vCoreSize = vCoreSize;
		this.domainName = domain;
	}
	
	public String getDomainName() {
		return domainName;
	}
	public boolean setDomainName(String domainName) {
		this.domainName = domainName;
		return true;
	}
	public Integer getNumberOfWorkers() {
		return numberOfWorkers;
	}
	public boolean setNumberOfWorkers(Integer numberOfWorkers) {
		this.numberOfWorkers = numberOfWorkers;
		return true;
	}
	public Double getvCoreSize() {
		return vCoreSize;
	}
	public boolean setvCoreSize(Double vCoreSize) {
		this.vCoreSize = vCoreSize;
		return true;
	}
	public Double getAverageCPU() {
		return averageCPU;
	}
	public boolean setAverageCPU(Double averageCPU) {
		this.averageCPU = averageCPU;
		return true;
	}
	public Double getAverageMemory() {
		return averageMemory;
	}
	public boolean setAverageMemory(Double averageMemory) {
		this.averageMemory = averageMemory;
		return true;
	}
	public Double getPeakCPU() {
		return peakCPU;
	}
	public boolean setPeakCPU(Double peakCPU) {
		this.peakCPU = peakCPU;
		return true;
	}
	public Double getPeakMemory() {
		return peakMemory;
	}
	public boolean setPeakMemory(Double peakMemory) {
		this.peakMemory = peakMemory;
		return true;
	}
	
	public Double getAverage(LinkedHashMap<Object,Object> values){
		Double total = new Double(0);
		int size = values.size();
		for (Entry<Object, Object> entry : values.entrySet()) {
			Double value;
			try{
				value = (Double) entry.getValue();
			}catch(Exception e){
				value = 0.0;
				size--;
			}
		    total += value;
		}
		Double average = total/size;
		return average;
	}
	
	public Double getMax(LinkedHashMap<Object,Object> values){
		Double highest = new Double(0);
		for (Entry<Object, Object> entry : values.entrySet()) {
			Double value;
			try{
				value = (Double) entry.getValue();
			}catch(Exception e){
				value = 0.0;
			}
		    if(value>highest){
		    	highest = value;
		    }
		}
		return highest;
	}
}
