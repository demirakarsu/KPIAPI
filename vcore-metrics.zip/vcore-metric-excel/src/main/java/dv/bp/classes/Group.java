package dv.bp.classes;

import java.util.ArrayList;


public class Group {
	
	private String groupName;
	private ArrayList<Domain> domains;
	
	public Group(){
	}
	
	public Group(String groupName){
		this.groupName = groupName;
	}
	
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public ArrayList<Domain> getDomains() {
		return domains;
	}
	
	public boolean addDomains(ArrayList<Domain> domains){
		if(this.domains == null){
			setDomains(domains);
		}else{
			for(int i = 0; i<domains.size(); i++){
				this.domains.add(domains.get(i));
			}
		}
		return true;
	}
	
	public boolean setDomains(ArrayList<Domain> domains ) {
		this.domains = domains;
		return true;
	}
	
	
}
